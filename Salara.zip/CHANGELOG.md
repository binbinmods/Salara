# 0.1.2

Changed Shield to only increase Mind Damage

Spiral costs 3 like it is supposed to

# 0.1.1

Fixed Ottis repeated procs of Liberation

Fixed Spiral's repeat count

# 0.1.0

Initial concept
