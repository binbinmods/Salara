# 0.2.0

Update for AtO v1.7.2

# 0.1.3

Self Reflect no longer can be crafted

Mind Maze no longer applies to Mind Spells, no longer is removed

Mentalmorphosis now reduces mind resistance

# 0.1.2

Changed Shield to only increase Mind Damage

Spiral costs 3 like it is supposed to

# 0.1.1

Fixed Ottis repeated procs of Liberation

Fixed Spiral's repeat count

# 0.1.0

Initial concept
